bl_info = {
    "name": "Viewport Display Color Change",
    "author": "Snipnip",
    "version": (2, 3, 1),
    "blender": (2, 93, 0),
    "location": "View3D > N-Panel > Viewport Display Color",
    "description": (
        "Create scripted drivers on a material's Viewport Display color with unlimited color states.\n"
        "Features include color pickers, a searchable Bone list, visual alerts if a custom property\n"
        "is missing, automatic custom property creation, caching of bone keys, and debug logging."
    ),
    "warning": "",
    "category": "Material",
}

import bpy
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup,
    UIList,
    Menu,
)
from bpy.props import (
    PointerProperty,
    FloatProperty,
    StringProperty,
    CollectionProperty,
    IntProperty,
    FloatVectorProperty,
    BoolProperty,
)

# Global variable for passing state between operators
current_color_state_index = -1
# Simple cache: maps bone.name to its list of user-defined custom property keys
custom_prop_cache = {}

# ----------------------------------------------------------------
# Poll function: restrict target_object to Armatures.
# ----------------------------------------------------------------
def poll_armature(self, obj):
    return (obj is not None and obj.type == 'ARMATURE')

# ----------------------------------------------------------------
# Collection Item: holds a single color state.
# ----------------------------------------------------------------
class COLORDRIVER_PG_ColorState(PropertyGroup):
    """
    A single color state entry contains:
    - A label,
    - A custom property name (the property to be read),
    - A color (via a color picker), and
    - An optional bone selection.
    
    When the target object is an armature, you can choose a bone from its pose.
    If that bone’s custom properties do not include the property name given,
    the field is highlighted and a button is offered to create the missing property.
    """
    name: StringProperty(
        name="Label",
        description="Label for your own reference",
        default="Color State"
    )
    var_name: StringProperty(
        name="",
        description="Custom property name to read (from bone or object)",
        default="var0"
    )
    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        description="Color state value"
    )
    target_bone: StringProperty(
        name="Bone",
        description=(
            "Optional: if the custom property is on a bone, select it here. "
            "Leave empty to use the object's custom property or auto-detect an active pose bone."
        ),
        default=""
    )

# ----------------------------------------------------------------
# Main Settings: includes base color, target, and a collection of states.
# ----------------------------------------------------------------
class COLORDRIVER_PG_settings(PropertyGroup):
    """
    Stores:
    - A pointer to the target material,
    - A pointer to the target armature/object,
    - A base color (via a color picker),
    - A dynamic list (collection) of color states,
    - And a debug flag.
    """
    material: PointerProperty(
        name="Material",
        type=bpy.types.Material,
        description="Select a material on the active object"
    )

    target_object: PointerProperty(
        name="Target Armature/Object",
        type=bpy.types.Object,
        poll=poll_armature,
        description=(
            "Which Object holds the custom properties used by the drivers? "
            "If an Armature is chosen, you can search for a bone and its custom properties."
        )
    )

    base_color: FloatVectorProperty(
        name="Base Color",
        subtype='COLOR',
        default=(0.4, 0.4, 0.4),
        min=0.0, max=1.0,
        description="Base color for the material"
    )

    color_states: CollectionProperty(type=COLORDRIVER_PG_ColorState)
    color_states_index: IntProperty(default=0)
    
    enable_debug: BoolProperty(
        name="Enable Debug",
        description="Print driver expressions to the console for debugging",
        default=False
    )

# ----------------------------------------------------------------
# UIList: displays all the color states.
# ----------------------------------------------------------------
class COLORDRIVER_UL_color_states(UIList):
    """
    Draws each entry of 'color_states' in a row.
    If the target object is an Armature, a bone search is provided.
    The custom property field is drawn with an alert (red) if its name is not found
    in the selected bone's custom properties. In that case, a "Create" button is shown
    so the missing property can be automatically created. Additionally, if any custom
    properties exist on the bone, a "Pick" button is available.
    """
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # 'item' is a COLORDRIVER_PG_ColorState.
        row = layout.row(align=True)
        row.prop(item, "name", text="", emboss=False, icon='COLOR')
        
        settings = context.scene.color_driver_settings
        target_obj = settings.target_object

        if target_obj and target_obj.type == 'ARMATURE':
            # Let the user search for a bone in the armature's pose.
            row.prop_search(item, "target_bone", target_obj.pose, "bones", text="Bone")
            if item.target_bone and item.target_bone in target_obj.pose.bones:
                bone = target_obj.pose.bones[item.target_bone]
                # Get custom property keys, recalculating every time for reliability.
                custom_keys = [k for k in bone.keys() if not k.startswith("_")]
                # (Optionally, you can use caching here—but if properties are deleted externally, the cache may become stale.)
                # custom_keys = custom_prop_cache.get(bone.name, [k for k in bone.keys() if not k.startswith("_")])
                # custom_prop_cache[bone.name] = custom_keys

                # Draw the var_name field. If the specified property is missing, alert the user.
                sub = row.row()
                if item.var_name not in custom_keys:
                    sub.alert = True
                sub.prop(item, "var_name", text="")

                # Always show the "Create" button if the property is missing.
                if item.var_name not in custom_keys:
                    op_create = row.operator("colordriver.create_custom_prop", text="Create", icon='PLUS')
                    op_create.state_index = index
                # If there are any custom properties on the bone, also show a "Pick" button.
                if custom_keys:
                    op_pick = row.operator("colordriver.pick_custom_prop", text="", icon='DOWNARROW_HLT')
                    op_pick.state_index = index
            else:
                row.prop(item, "var_name", text="")
        else:
            # Fallback for non-armature targets.
            row.prop(item, "target_bone", text="Bone")
            row.prop(item, "var_name", text="")
        row.prop(item, "color", text="")

# ----------------------------------------------------------------
# Operator: Add a new color state.
# ----------------------------------------------------------------
class COLORDRIVER_OT_add_color_state(Operator):
    bl_idname = "colordriver.add_color_state"
    bl_label = "Add Color State"
    bl_description = "Add a new color state to the list"

    def execute(self, context):
        props = context.scene.color_driver_settings
        new_item = props.color_states.add()
        new_item.name = f"ColorState_{len(props.color_states)}"
        new_item.var_name = f"var_{len(props.color_states)}"
        new_item.color = props.base_color  # default to the base color
        new_item.target_bone = ""            # start with no bone selected
        props.color_states_index = len(props.color_states) - 1
        return {'FINISHED'}

# ----------------------------------------------------------------
# Operator: Remove the active color state.
# ----------------------------------------------------------------
class COLORDRIVER_OT_remove_color_state(Operator):
    bl_idname = "colordriver.remove_color_state"
    bl_label = "Remove Color State"
    bl_description = "Remove the active color state from the list"

    def execute(self, context):
        props = context.scene.color_driver_settings
        index = props.color_states_index
        if 0 <= index < len(props.color_states):
            props.color_states.remove(index)
            props.color_states_index = min(index, len(props.color_states) - 1)
        return {'FINISHED'}

# ----------------------------------------------------------------
# Operator: Create/Update drivers.
# ----------------------------------------------------------------
class COLORDRIVER_OT_apply(Operator):
    bl_idname = "colordriver.apply_dynamic"
    bl_label = "Apply Drivers"
    bl_description = (
        "Create/Update drivers for the selected material's Viewport Display color, using the base color "
        "and all additional color states. For each state, if a bone is selected (or auto-detected), "
        "the driver variable will reference the custom property on that bone; otherwise it references "
        "the target object's custom property."
    )

    @classmethod
    def poll(cls, context):
        props = context.scene.color_driver_settings
        return (props.material is not None and props.target_object is not None)

    def execute(self, context):
        props = context.scene.color_driver_settings
        mat = props.material
        target_obj = props.target_object

        # Ensure the material has animation data.
        if not mat.animation_data:
            mat.animation_data_create()

        def create_driver_for_channel(channel_index, base_val, states_vals):
            # Try to get an existing fcurve.
            try:
                fcurve = mat.driver_add("diffuse_color", channel_index)
            except TypeError:
                fcurves = mat.animation_data.drivers
                fcurve = None
                for fc in fcurves:
                    if fc.data_path == "diffuse_color" and fc.array_index == channel_index:
                        fcurve = fc
                        break
                if not fcurve:
                    fcurve = mat.driver_add("diffuse_color", channel_index)

            driver = fcurve.driver
            driver.type = 'SCRIPTED'

            # Remove any existing variables.
            while driver.variables:
                driver.variables.remove(driver.variables[0])

            expression = f"{base_val}"
            for (delta, var_name, bone_str) in states_vals:
                var = driver.variables.new()
                var.name = var_name
                var.type = 'SINGLE_PROP'
                var.targets[0].id_type = 'OBJECT'
                var.targets[0].id = target_obj

                bone_name = bone_str.strip() if bone_str.strip() else ""
                if not bone_name:
                    if target_obj.type == 'ARMATURE' and context.active_pose_bone:
                        bone_name = context.active_pose_bone.name

                if bone_name:
                    var.targets[0].data_path = f'pose.bones["{bone_name}"]["{var_name}"]'
                else:
                    var.targets[0].data_path = f'["{var_name}"]'
                expression += f" +(({delta})*{var_name})"

            # Only update if changed.
            if driver.expression != expression:
                driver.expression = expression
                if props.enable_debug:
                    print(f"Updated driver expression for channel {channel_index}: {expression}")

        base_color = props.base_color
        states_r = []
        states_g = []
        states_b = []

        # Compute the delta for each color state.
        for state in props.color_states:
            delta_r = state.color[0] - base_color[0]
            delta_g = state.color[1] - base_color[1]
            delta_b = state.color[2] - base_color[2]
            states_r.append((delta_r, state.var_name, state.target_bone))
            states_g.append((delta_g, state.var_name, state.target_bone))
            states_b.append((delta_b, state.var_name, state.target_bone))

        create_driver_for_channel(0, base_color[0], states_r)  # R channel
        create_driver_for_channel(1, base_color[1], states_g)  # G channel
        create_driver_for_channel(2, base_color[2], states_b)  # B channel

        self.report({'INFO'}, "Dynamic color drivers applied/updated successfully.")
        return {'FINISHED'}

# ----------------------------------------------------------------
# Operator: Launch the custom property picker.
# ----------------------------------------------------------------
class COLORDRIVER_OT_pick_custom_prop(Operator):
    bl_idname = "colordriver.pick_custom_prop"
    bl_label = "Pick Custom Property"
    bl_description = "Show a menu of custom properties from the selected bone"
    state_index: IntProperty()

    def execute(self, context):
        global current_color_state_index
        current_color_state_index = self.state_index
        bpy.ops.wm.call_menu(name="COLORDRIVER_MT_custom_prop_menu")
        return {'FINISHED'}

# ----------------------------------------------------------------
# Operator: Automatically create the custom property on the selected bone.
# ----------------------------------------------------------------
class COLORDRIVER_OT_create_custom_prop(Operator):
    bl_idname = "colordriver.create_custom_prop"
    bl_label = "Create Custom Property"
    bl_description = "Automatically create the custom property on the selected bone"
    state_index: IntProperty()

    def execute(self, context):
        settings = context.scene.color_driver_settings
        if self.state_index < 0 or self.state_index >= len(settings.color_states):
            self.report({'ERROR'}, "Invalid state index")
            return {'CANCELLED'}
        state = settings.color_states[self.state_index]
        target_obj = settings.target_object
        if not (target_obj and target_obj.type == 'ARMATURE'):
            self.report({'ERROR'}, "Target is not an armature")
            return {'CANCELLED'}
        if not state.target_bone:
            self.report({'ERROR'}, "No bone selected")
            return {'CANCELLED'}
        bone = target_obj.pose.bones.get(state.target_bone)
        if bone is None:
            self.report({'ERROR'}, "Bone not found")
            return {'CANCELLED'}
        # Create the custom property with a default value (0.0)
        bone[state.var_name] = 0.0
        # Clear the cached keys for this bone so that the UI updates.
        global custom_prop_cache
        if bone.name in custom_prop_cache:
            del custom_prop_cache[bone.name]
        self.report({'INFO'}, f"Custom property '{state.var_name}' created on bone '{bone.name}'")
        return {'FINISHED'}

# ----------------------------------------------------------------
# Menu: Dynamically lists the custom property keys from the selected bone.
# ----------------------------------------------------------------
class COLORDRIVER_MT_custom_prop_menu(Menu):
    bl_label = "Select Custom Property"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.color_driver_settings
        idx = current_color_state_index
        if idx < 0 or idx >= len(settings.color_states):
            layout.label(text="No valid state")
            return
        state = settings.color_states[idx]
        target_obj = settings.target_object
        if target_obj and target_obj.type == 'ARMATURE' and state.target_bone in target_obj.pose.bones:
            bone = target_obj.pose.bones[state.target_bone]
            keys = [k for k in bone.keys() if not k.startswith("_")]
            if not keys:
                layout.label(text="No custom properties found")
            else:
                for key in keys:
                    op = layout.operator("colordriver.set_custom_prop", text=key)
                    op.state_index = idx
                    op.prop_key = key
        else:
            layout.label(text="No bone selected")

# ----------------------------------------------------------------
# Operator: Set the custom property (variable name) for a color state.
# ----------------------------------------------------------------
class COLORDRIVER_OT_set_custom_prop(Operator):
    bl_idname = "colordriver.set_custom_prop"
    bl_label = "Set Custom Property"
    state_index: IntProperty()
    prop_key: StringProperty()

    def execute(self, context):
        settings = context.scene.color_driver_settings
        if self.state_index < 0 or self.state_index >= len(settings.color_states):
            return {'CANCELLED'}
        settings.color_states[self.state_index].var_name = self.prop_key
        return {'FINISHED'}

# ----------------------------------------------------------------
# Panel: main UI.
# ----------------------------------------------------------------
class COLORDRIVER_PT_panel(Panel):
    bl_label = "Viewport Display Color"
    bl_idname = "COLORDRIVER_PT_panel_dynamic"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Viewport Display Color"

    def draw(self, context):
        layout = self.layout
        props = context.scene.color_driver_settings

        layout.label(text="1) Choose Material & Target Object")
        layout.prop(props, "material")
        layout.prop(props, "target_object")

        layout.separator()
        layout.label(text="2) Base Color:")
        layout.prop(props, "base_color", text="")

        layout.separator()
        layout.label(text="3) Additional Color States:")
        row = layout.row()
        row.template_list(
            "COLORDRIVER_UL_color_states",  # UIList class
            "",                             # list_id (unused)
            props,                          # Pointer to settings
            "color_states",                 # Collection property name
            props,                          # Pointer to active settings
            "color_states_index",           # Active index property
            rows=3
        )
        col = row.column(align=True)
        col.operator("colordriver.add_color_state", icon='ADD', text="")
        col.operator("colordriver.remove_color_state", icon='REMOVE', text="")

        # Alert if the active state has a bone selected but that bone does not have the property.
        active_idx = props.color_states_index
        if active_idx >= 0 and active_idx < len(props.color_states):
            state = props.color_states[active_idx]
            if state.target_bone:
                armature = props.target_object
                if armature and armature.type == 'ARMATURE':
                    bone = armature.pose.bones.get(state.target_bone)
                    if bone:
                        keys = [k for k in bone.keys() if not k.startswith("_")]
                        if state.var_name not in keys:
                            layout.label(text=f"Warning: Bone '{state.target_bone}' is missing property '{state.var_name}'!", icon='ERROR')

        layout.separator()
        layout.prop(props, "enable_debug", text="Enable Debug")
        layout.operator("colordriver.apply_dynamic", icon='FILE_TICK')

# ----------------------------------------------------------------
# Registration
# ----------------------------------------------------------------
classes = (
    COLORDRIVER_PG_ColorState,
    COLORDRIVER_PG_settings,
    COLORDRIVER_UL_color_states,
    COLORDRIVER_OT_add_color_state,
    COLORDRIVER_OT_remove_color_state,
    COLORDRIVER_OT_apply,
    COLORDRIVER_OT_pick_custom_prop,
    COLORDRIVER_MT_custom_prop_menu,
    COLORDRIVER_OT_set_custom_prop,
    COLORDRIVER_OT_create_custom_prop,
    COLORDRIVER_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.color_driver_settings = PointerProperty(type=COLORDRIVER_PG_settings)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.color_driver_settings

if __name__ == "__main__":
    register()
